# -*- coding: utf-8 -*-
"""
Supporting functions for  the Subscriber
"""
import paho.mqtt.client as mqtt
import time
import math
import string
import random
from datetime import datetime
import pprint
from sys import getsizeof
import json

def on_connect(client, userdata, flags, rc,qos=0):
    print("Connected with result code "+str(rc))
def generate_random_string(ncharacters):
    res= ''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(ncharacters))
    return res;

def package_data(n_char=3):

    assert n_char<=2048,"Valid load size";

    now = datetime.utcnow()

    current_time = now.strftime('\"%Y-%m-%d %H:%M:%S.%f\"')[:-3];
    res=""
    header = '{ \"ProviderID\":\"' + "DDN" + '\",\"utc_published_time\":' + current_time + "\" "
    random_data=""
    print('&&&&& '+ str(n_char));
    random_data= ''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(n_char));
#    random_data="";
    print("*Length="+str(len(random_data)));
    if (len(random_data)>3):
        print("Boom!!!!!!!!"+str(n_char))
        random_data = ''.join(
            random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(n_char));
    if (len(random_data)>n_char):
        print("0"+str(n_char)+"000000000000000000000000000")
        random_data = ''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(n_char));
        print("-->Length=" + str(len(random_data)));
    assert len(random_data)==n_char, "Valid random string length!"
    load =header+",\"Data\"=\""+random_data+"\", \"DataSize\"="+ str(getsizeof(random_data))+ "}"
    # Do the encryption here. Set last parameter to 0 to apply NO encryption
    res= load;
    return res;
  #  print("nchar="+ str(nchar));
def convert_size(size_bytes):
   if size_bytes == 0:
       return "0B"
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size_bytes, 1024)))
   p = math.pow(1024, i)
   s = round(size_bytes / p, 2)
   return "%s %s" % (s, size_name[i])


def PublishNow(dst_host="test.mosquitto.org",dst_topic="Deltatest",retention_time=1):
    """
    Continuously publish  to the dest_host under dest_topic with qos
    Params:
    1. dst_host: destination hostname or IP of the destination MQTT Broker
    2. dst_topic: MQTT topic to subscribe
    3. qos: Quality of service
    4.listen_time: The yime to listen to the Provider: IN MINUTE

    Returns:
    1. Nothing, message is appened to global variable rs

    """
    dst_topic=dst_topic

    print(">>Publishing to [{0}] under topic of \"{1}\" in {2} minutes".format(dst_host,dst_topic,retention_time));
# The callback for when the client receives a CONNACK response from the server.
    startTime = time.time()
    endTime= startTime;
    runTime = retention_time * 60 # Runtime of 3 seconds

    client = mqtt.Client()
    client.on_connect = on_connect

    client.connect(dst_host, 1883, 10)

    while True:
        client.loop()
        currentTime = time.time()
        ###################
        # Now do the publish
        load = package_data(3)
        print(load);
        print(convert_size(getsizeof(load)))
        client.publish(topic=dst_topic, payload=load);
        ##########
        if (currentTime - startTime) > runTime:
            endTime= time.time()
            break
    ###################
    # Now do the publish
    load = package_data(128)
    print(load);
    print(convert_size(getsizeof(load)))
    client.publish(topic=dst_topic, payload=load);
    ##########
    return (load,startTime,endTime)
# Blocking call that processes network traffic, dispatches callbacks and
# handles reconnecting.
# Other loop*() functions are available that give a threaded interface and a
# manual interface.
#    client.loop_forever(timeout=0.01,max_packets=100)
#    client.loop(timeout=0.5)