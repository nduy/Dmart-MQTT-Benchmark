# LIBRARIES
import paho.mqtt.client as mqtt
from datetime import datetime
import random
import string
from datetime import datetime
import time
import re
import math
import os
import sys
import ast
import requests
from termcolor import colored
import pprint
from sys import getsizeof
from lib import *

def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    """
    print("!!!!")
    BROKER_HOSTNAME = int(input("Please input the hostname or IP or the broker"));
    RETENT_TIME = float(input("For how long do you want to publish the stream(in minutes"));
    NUMBER_CHARACTER = int(input("How many random characters do you want the Data load to be?"))
    load = package_data(128)
    print(load);
    print(convert_size(getsizeof(load)))
    """
    PublishNow(dst_host="52.19.248.189", dst_topic="Deltatest", retention_time=0.1)
